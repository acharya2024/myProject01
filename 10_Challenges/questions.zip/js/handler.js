document.addEventListener("DOMContentLoaded", function () {
    // Load questions from JSON file
    fetch("questions.json")
        .then((response) => {
            if (!response.ok) {
                throw new Error("Failed to fetch questions.json");
            }
            return response.text(); // Fetch as text to preprocess
        })
        .then((text) => {
            const sanitizedText = text//.replace(/\\/g, "\\\\").replace(/\"/g, "\\\"");
            const data = JSON.parse(sanitizedText);
            loadQuestions(data);
        })
        .catch((error) => {
            console.error("Error loading questions: ", error);
        });

    // Function to load questions into the HTML
    function loadQuestions(data) {
        const contentDiv = document.getElementById("content");
        const questionList = document.createElement("ul");
        questionList.classList.add("list-group");

        data.questions.forEach((question, index) => {
            // Create list item
            const listItem = document.createElement("li");
            listItem.classList.add("list-group-item");

            // Create details for the entire question
            const questionDetails = document.createElement("details");
            const questionSummary = document.createElement("summary");
            questionSummary.innerHTML = `<strong>${index + 1}. ${question.title || "Question Title"}</strong>`; // Add serial number and bold title
            questionDetails.appendChild(questionSummary);

            // Add question text
            if (question.questionText) {
                const questionText = document.createElement("div");
                questionText.innerHTML = wrapTextInParagraphs(processDiagrams(`${question.questionText}`, question.id));
                questionDetails.appendChild(questionText);
            }

            // Create details for answer key if available
            if (question.answer) {
                const answerDetails = document.createElement("details");
                const answerSummary = document.createElement("summary");
                answerSummary.textContent = "Answer Key";
                answerDetails.appendChild(answerSummary);
                const answerContent = document.createElement("div");
                answerContent.innerHTML = wrapTextInParagraphs(question.answer);
                answerDetails.appendChild(answerContent);
                questionDetails.appendChild(answerDetails);
            }

            // Create details for hint if available
            if (question.hint) {
                const hintDetails = document.createElement("details");
                const hintSummary = document.createElement("summary");
                hintSummary.textContent = "Hint";
                hintDetails.appendChild(hintSummary);
                const hintContent = document.createElement("div");
                hintContent.innerHTML = wrapTextInParagraphs(question.hint);
                hintDetails.appendChild(hintContent);
                questionDetails.appendChild(hintDetails);
            }

            // Create details for method to solve if available
            if (question.methodOfSolving && question.methodOfSolving.length > 0) {
                const methodDetails = document.createElement("details");
                const methodSummary = document.createElement("summary");
                methodSummary.textContent = "Method to Solve";
                methodDetails.appendChild(methodSummary);
                const methodList = document.createElement("ul");
                question.methodOfSolving.forEach((step, stepIndex) => {
                    const stepItem = document.createElement("li");
                    stepItem.textContent = `Step ${stepIndex + 1}: ${step}`;
                    methodList.appendChild(stepItem);
                });
                methodDetails.appendChild(methodList);
                questionDetails.appendChild(methodDetails);
            }

            // Create details for solution if available
            if (question.solution) {
                const solutionDetails = document.createElement("details");
                const solutionSummary = document.createElement("summary");
                solutionSummary.textContent = "Detailed Solution";
                solutionDetails.appendChild(solutionSummary);
                const solutionContent = document.createElement("div");
                solutionContent.innerHTML = wrapTextInParagraphs(processDiagrams(question.solution, question.id));
                solutionDetails.appendChild(solutionContent);
                questionDetails.appendChild(solutionDetails);
            }

            // Append the question details to the list item
            listItem.appendChild(questionDetails);

            // Append list item to the question list
            questionList.appendChild(listItem);
        });

        // Append the question list to the content div
        contentDiv.appendChild(questionList);

        // Trigger MathJax to render math expressions
        if (window.MathJax) {
            MathJax.typesetPromise().catch((err) => console.error("MathJax rendering error: ", err));
        }
    }

    // Function to replace diagram placeholders with image paths
    function processDiagrams(text, questionId) {
        return text.replace(/DIAGRAM\[(\d+),(\d+)\]/g, (_, diagramNumber, width) => {
            return `<img src="dia/${questionId}_${diagramNumber}.png" alt="Diagram ${diagramNumber}" style="max-width:${width}px; margin-left: 30px;">`;
        });
    }

    // Function to wrap text in <p> tags for new lines
    function wrapTextInParagraphs(text) {
        return text
            .split("\\n")
            .map((line) => {
                if (line.trim().startsWith("\\(") && !line.includes("\\Rightarrow")) {
                    // Add margin for lines starting with \( but not containing \Rightarrow
                    return `<p style="margin-left: 20px;">${line}</p>`;
                }
                return `<p>${line}</p>`;
            })
            .join("");
    }
});
